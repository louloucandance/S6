#ifndef TP1HPP
#define TP1HPP
#include <cstring>

namespace fonctions{
	
	size_t strlen_(const char* str);
	void strcpy_(char *, const char *);
	char* strncpy_(char *, const char *, size_t);
		
}
#endif
